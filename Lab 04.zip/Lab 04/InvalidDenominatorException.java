/**
 * Exception for invalid denominators.
 * Exception for invalid denominators..This exception is used when a Rational number has a denominator of zero.
 * It is a checked exception, so the program must handle it using try-catch
 * or declare it with 'throws' in the method.
 */
 */
class InvalidDenominatorException extends Exception {
    public InvalidDenominatorException(String message) {
        super(message);
    }
}