public class RationalTest {
    public static void main(String[] args) {
        System.out.println(" Normal Cases");
        try {
            Rational r1 = new Rational(1, 2); // 1/2
            Rational r2 = new Rational(3, 4); // 3/4

            System.out.println("r1 = " + r1); // 1/2
            System.out.println("r2 = " + r2); // 3/4

            Rational add = r1.add(r2);
            System.out.println("r1 + r2 = " + add); // 5/4

            Rational add2 = r1.add2(r2);
            System.out.println("r1 + r2 (2) = " + add2); // 5/4

            System.out.println("r1 > r2? " + r1.isGreaterThan(r2)); // false
            System.out.println("r2 > r1? " + r2.isGreaterThan(r1)); // true

        } catch (InvalidDenominatorException e) {
            System.out.println("Invalid denominator: " + e.getMessage());
        }
        // Simplify test (mutating)
            Rational r3 = new Rational(2, 4); // 2/4
            System.out.println("Before simplify: " + r3); // shows 2/4
            r3.simplify(); // changes r3 itself to 1/2
            System.out.println("After simplify: " + r3); // shows 1/2

        System.out.println("\n Boundary Cases");
        try {
            Rational zero = new Rational(0, 5); // 0/5 simplifies to 0/1
            Rational negative = new Rational(-2, 3); // -2/3
            Rational one = new Rational(5, 5); // 5/5 simplifies to 1/1

            System.out.println("zero = " + zero); // 0/1
            System.out.println("negative = " + negative); // -2/3
            System.out.println("one = " + one); // 1/1

            System.out.println("zero + negative = " + zero.add(negative)); // -2/3
            System.out.println("one + negative = " + one.add(negative)); // 1/3

        } catch (InvalidDenominatorException e) {
            System.out.println("Invalid denominator: " + e.getMessage());
        }

        System.out.println("\n Error Cases ");
        try {
            Rational invalid = new Rational(1, 0); // should throw exception
        } catch (InvalidDenominatorException e) {
            System.out.println("Caught error for denominator 0: " + e.getMessage());
        }

        try {
            Rational r = new Rational(1, 2);
            Rational nullR = null;

            // Testing null references
            r.isGreaterThan(nullR); // should throw IllegalArgumentException
        } catch (Exception e) {
            System.out.println("Caught error for null reference: " + e);
        }

        try {
            Rational r = new Rational(1, 2);
            Rational nullR = null;

            // Testing add with null
            r.add(nullR); // should throw NullPointerException
        } catch (Exception e) {
            System.out.println("Caught error for add(null): " + e);
        }
    }
}
/**
 * Manual test harness for Rational class.
 *
 * Specifications:
 *
 * Normal Cases
 * 1. Create two normal fractions (1/2 and 3/4).
 * 2. Print their values.
 * 3. Test addition using both add() and addAlt() methods.
 * 4. Test comparison using isGreaterThan().
 *
 *  Boundary Cases 
 * 1. Test fractions with numerator 0 (0/5 simplifies to 0/1).
 * 2. Test negative fractions (-2/3).
 * 3. Test fractions that simplify to 1 (5/5 simplifies to 1/1).
 * 4. Test addition involving zero, negative, and simplified fractions.
 *
 *  Error Cases
 * 1. Test creation of a fraction with denominator 0 → should throw InvalidDenominatorException.
 * 2. Test isGreaterThan() with a null reference → should throw IllegalArgumentException.
 * 3. Test add() with a null reference → should throw NullPointerException.
 */
/*  Mutating vs Non-Mutating:
 * - add() is non-mutating → returns a new Rational, original unchanged.
 * - simplify() is mutating → modifies the current Rational object.
 */