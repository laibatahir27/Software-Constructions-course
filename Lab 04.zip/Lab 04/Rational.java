/**
 * Class representing a Rational number (fraction).
 * 
 * Invariants:
 *  - Denominator != 0
 *  - Rational numbers should be kept in simplest form when possible
 */
public class Rational {
    private int numerator;
    private int denominator;

    /**
     * Constructor for Rational.
     * @param num numerator
     * @param den denominator (must not be zero)
     * @throws InvalidDenominatorException if denominator = 0
     * @throws ArithmeticException if num or den too large
     */
    public Rational(int num, int den) throws InvalidDenominatorException {
        if (den == 0) {
            throw new InvalidDenominatorException("Denominator cannot be zero.");
        }

        /**  Optional: check for overflow
         Check if numerator or denominator is too large
 If so, throw an ArithmeticException to prevent overflow errors.
 */
        if (num == Integer.MIN_VALUE || den == Integer.MIN_VALUE) {
            throw new ArithmeticException("Value too large");
        }

        this.numerator = num;
        this.denominator = den;

        simplify(); // always store in simplest form
    }

    /**
     * Adds this Rational to another Rational.
     * Non-mutating: returns a new Rational, does not modify this.
     * @param other the Rational to add (must not be null)
     * @return a new Rational representing the sum
     */
    public Rational add(Rational other) {
        if (other == null) {
            throw new NullPointerException("Other Rational cannot be null");
        }

        int newNum = this.numerator * other.denominator + other.numerator * this.denominator;
        int newDen = this.denominator * other.denominator;

        try {
            return new Rational(newNum, newDen);
        } catch (InvalidDenominatorException e) {
            // This should never happen because newDen cannot be 0
            throw new RuntimeException(e);
        }
    }public Rational add2(Rational other) {
    if (other == null) throw new NullPointerException("Other Rational cannot be null");

    Rational r1 = new Rational(this.numerator, this.denominator);
    Rational r2 = new Rational(other.numerator, other.denominator);

    r1.simplify();
    r2.simplify();

    int newNum = r1.numerator * r2.denominator + r2.numerator * r1.denominator;
    int newDen = r1.denominator * r2.denominator;

    try {
        return new Rational(newNum, newDen);
    } catch (InvalidDenominatorException e) {
        throw new RuntimeException(e);
    }
} 

    


    /**
     * Simplifies this Rational in-place.
     * Mutating: modifies current object.
     */
    public void simplify() {
        int gcd = gcd(Math.abs(numerator), Math.abs(denominator));
        numerator /= gcd;
        denominator /= gcd;

        // Keep denominator positive
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

    /**
     * Computes GCD of two numbers
 * Simplifies this Rational number by dividing numerator and denominator
 * by their greatest common divisor (GCD).
 * This modifies the current object to its simplest form.
 */
     */
    private int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    /**
     * Compares equality of this Rational with another object.
     * @param obj object to compare with
     * @return true if obj is a Rational with equal value
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Rational)) return false;

        Rational other = (Rational) obj;
        return this.numerator * other.denominator == other.numerator * this.denominator;
    }

    /**
     * Compare this Rational with another Rational.
     * @param other other Rational (must not be null)
     * @return true if this > other
     * @throws IllegalArgumentException if other is null
     */
    public boolean isGreaterThan(Rational other) {
        if (other == null) {
            throw new IllegalArgumentException("Other Rational cannot be null");
        }

        return this.numerator * other.denominator > other.numerator * this.denominator;
    }
    public boolean isGreaterThanNoCheck(Rational other) {
    // No check for null; will throw NullPointerException automatically if other is null
    return this.numerator * other.denominator > other.numerator * this.denominator;
}

    @Override
    public String toString() {
        return numerator + "/" + denominator;
    }
}

/**
 * Exception for invalid denominators.
 * Exception for invalid denominators..This exception is used when a Rational number has a denominator of zero.
 * It is a checked exception, so the program must handle it using try-catch
 * or declare it with 'throws' in the method.
 */
 */
class InvalidDenominatorException extends Exception {
    public InvalidDenominatorException(String message) {
        super(message);
    }
}