/**  Optional: check for overflow
         Check if numerator or denominator is too large
 If so, throw an ArithmeticException to prevent overflow errors.
 */
        if (num == Integer.MIN_VALUE || den == Integer.MIN_VALUE) {
            throw new ArithmeticException("Value too large");
        }

        this.numerator = num;
        this.denominator = den;

        simplify(); // always store in simplest form
    }
	/**unchecked 
	*/
	 Unchecked exception
public class OverflowException extends RuntimeException {
    public OverflowException(String msg) {
        super(msg);
    }
}